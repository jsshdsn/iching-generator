import hexagrams from './hexagrams.js';

// DOM elements
const hexagramDisplay = document.getElementById('hexagram-display');
const hexagramNumber = document.getElementById('hexagram-number');
const hexagramName = document.getElementById('hexagram-name');
const hexagramMeaning = document.getElementById('hexagram-meaning');
const generateBtn = document.getElementById('generate-btn');

// Generate a random hexagram
function generateHexagram() {
  // Clear previous hexagram
  hexagramDisplay.innerHTML = '';
  
  // Generate 6 random lines (0 for yin, 1 for yang)
  let binaryString = '';
  
  for (let i = 0; i < 6; i++) {
    const isYang = Math.random() < 0.5;
    binaryString += isYang ? '1' : '0';
    
    // Create line element
    const lineDiv = document.createElement('div');
    lineDiv.className = 'line';
    
    if (isYang) {
      // Yang line (solid)
      const yangLine = document.createElement('div');
      yangLine.className = 'yang';
      lineDiv.appendChild(yangLine);
    } else {
      // Yin line (broken)
      const yinLine1 = document.createElement('div');
      yinLine1.className = 'yin';
      const yinLine2 = document.createElement('div');
      yinLine2.className = 'yin';
      lineDiv.appendChild(yinLine1);
      lineDiv.appendChild(yinLine2);
    }
    
    hexagramDisplay.appendChild(lineDiv);
  }
  
  // Find the corresponding hexagram
  const hexagram = hexagrams.find(h => h.binary === binaryString);
  
  if (hexagram) {
    hexagramNumber.textContent = `Hexagram ${hexagram.number}`;
    hexagramName.textContent = hexagram.name;
    hexagramMeaning.textContent = hexagram.meaning;
  } else {
    // This shouldn't happen with our complete list, but just in case
    hexagramNumber.textContent = 'Hexagram';
    hexagramName.textContent = 'Custom pattern';
    hexagramMeaning.textContent = 'No specific meaning found for this pattern.';
  }
}

// Event listener for the generate button
generateBtn.addEventListener('click', generateHexagram);

// Generate a hexagram on page load
generateHexagram();
