// This file contains the data for all 64 I Ching hexagrams

pub struct HexagramData {
    pub number: u8,
    pub name: &'static str,
    pub meaning: &'static str,
}

pub const HEXAGRAMS: [HexagramData; 64] = [
    HexagramData {
        number: 1,
        name: "Force (Qián)",
        meaning: "The Creative, Heaven. The creative power is the beginning of all things. It is strong, dynamic, and persevering. This hexagram suggests creative power, strength, and the ability to bring ideas into reality. It encourages taking initiative and leadership.",
    },
    HexagramData {
        number: 2,
        name: "Field (Kūn)",
        meaning: "The Receptive, Earth. The receptive power represents the perfect complement to the creative power. It is yielding, devoted, and receptive. This hexagram suggests receptivity, patience, and nurturing. It encourages acceptance and following rather than leading.",
    },
    // ... remaining hexagrams would be defined here
    HexagramData {
        number: 64,
        name: "Not-Yet Fording (Wèi Jì)",
        meaning: "Before Completion. Final stages require care. This hexagram suggests a time when completion is near but not yet achieved. It encourages careful attention to final details before conclusion.",
    },
];

// Function to get hexagram data by number (1-64)
pub fn get_hexagram_by_number(number: u8) -> Option<&'static HexagramData> {
    if number < 1 || number > 64 {
        return None;
    }
    
    Some(&HEXAGRAMS[(number - 1) as usize])
}
