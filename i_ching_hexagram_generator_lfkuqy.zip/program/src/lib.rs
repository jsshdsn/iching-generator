use anchor_lang::prelude::*;
use switchboard_v2::{VrfAccountData, VrfRequestRandomness};

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS"); // Replace with your program ID

#[program]
pub mod iching_generator {
    use super::*;

    // Initialize the program with a VRF account
    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let iching_account = &mut ctx.accounts.iching_account;
        iching_account.authority = ctx.accounts.user.key();
        iching_account.vrf = ctx.accounts.vrf.key();
        iching_account.hexagram = 0; // Default value
        iching_account.binary_lines = [false; 6]; // Default value
        Ok(())
    }

    // Request a new hexagram using VRF
    pub fn request_hexagram(ctx: Context<RequestHexagram>) -> Result<()> {
        let iching_account = &mut ctx.accounts.iching_account;
        
        // Request randomness from Switchboard VRF
        let switchboard_program = ctx.accounts.switchboard_program.to_account_info();
        let vrf = ctx.accounts.vrf.to_account_info();
        let authority = ctx.accounts.authority.to_account_info();
        
        let params = VrfRequestRandomness {
            authority,
            vrf,
            switchboard_program,
            payer: ctx.accounts.user.to_account_info(),
            oracle_queue: ctx.accounts.oracle_queue.to_account_info(),
            queue_authority: ctx.accounts.queue_authority.to_account_info(),
            data_buffer: ctx.accounts.data_buffer.to_account_info(),
            permission: ctx.accounts.permission.to_account_info(),
            escrow: ctx.accounts.escrow.clone(),
            payment_wallet: ctx.accounts.payment_wallet.clone(),
            state: ctx.accounts.state.to_account_info(),
            recent_blockhashes: ctx.accounts.recent_blockhashes.to_account_info(),
            program_state: ctx.accounts.program_state.to_account_info(),
            token_program: ctx.accounts.token_program.to_account_info(),
        };

        params.request_randomness()?;
        
        Ok(())
    }

    // Consume the VRF result and generate a hexagram
    pub fn consume_randomness(ctx: Context<ConsumeRandomness>) -> Result<()> {
        let vrf = ctx.accounts.vrf.load()?;
        let result_buffer = vrf.get_result()?;
        if result_buffer == [0u8; 32] {
            return Err(ErrorCode::VrfNotReady.into());
        }
        
        let iching_account = &mut ctx.accounts.iching_account;
        
        // Use the random bytes to generate the hexagram
        let mut binary_lines = [false; 6];
        for i in 0..6 {
            // Use one byte for each line
            binary_lines[i] = result_buffer[i] & 1 == 1; // true for yang (1), false for yin (0)
        }
        
        iching_account.binary_lines = binary_lines;
        
        // Convert binary lines to hexagram number (1-64)
        let mut binary_value = 0u8;
        for i in 0..6 {
            if binary_lines[i] {
                binary_value |= 1 << i;
            }
        }
        
        // Map the binary value (0-63) to hexagram number (1-64)
        iching_account.hexagram = (binary_value + 1) as u8;
        
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(init, payer = user, space = 8 + 32 + 32 + 1 + 6)]
    pub iching_account: Account<'info, IChingAccount>,
    pub vrf: AccountInfo<'info>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RequestHexagram<'info> {
    #[account(mut, has_one = authority, has_one = vrf)]
    pub iching_account: Account<'info, IChingAccount>,
    #[account(mut)]
    pub vrf: AccountInfo<'info>,
    pub authority: AccountInfo<'info>,
    pub switchboard_program: AccountInfo<'info>,
    pub oracle_queue: AccountInfo<'info>,
    pub queue_authority: AccountInfo<'info>,
    pub data_buffer: AccountInfo<'info>,
    pub permission: AccountInfo<'info>,
    pub escrow: AccountInfo<'info>,
    pub payment_wallet: AccountInfo<'info>,
    pub state: AccountInfo<'info>,
    pub recent_blockhashes: AccountInfo<'info>,
    pub program_state: AccountInfo<'info>,
    pub token_program: AccountInfo<'info>,
    #[account(mut)]
    pub user: Signer<'info>,
}

#[derive(Accounts)]
pub struct ConsumeRandomness<'info> {
    #[account(mut, has_one = vrf)]
    pub iching_account: Account<'info, IChingAccount>,
    #[account(mut)]
    pub vrf: AccountLoader<'info, VrfAccountData>,
    pub authority: Signer<'info>,
}

#[account]
pub struct IChingAccount {
    pub authority: Pubkey,
    pub vrf: Pubkey,
    pub hexagram: u8,       // 1-64 hexagram number
    pub binary_lines: [bool; 6], // true for yang (solid), false for yin (broken)
}

#[error_code]
pub enum ErrorCode {
    #[msg("VRF result not ready")]
    VrfNotReady,
}
