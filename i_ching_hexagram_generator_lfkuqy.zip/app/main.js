import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';
import { Program, AnchorProvider, web3 } from '@project-serum/anchor';

// Hexagram data
const hexagrams = [
  { 
    number: 1, 
    name: "Force (Qián)", 
    meaning: "The Creative, Heaven. The creative power is the beginning of all things. It is strong, dynamic, and persevering. This hexagram suggests creative power, strength, and the ability to bring ideas into reality. It encourages taking initiative and leadership."
  },
  { 
    number: 2, 
    name: "Field (Kūn)", 
    meaning: "The Receptive, Earth. The receptive power represents the perfect complement to the creative power. It is yielding, devoted, and receptive. This hexagram suggests receptivity, patience, and nurturing. It encourages acceptance and following rather than leading."
  },
  // ... all 64 hexagrams would be defined here
];

// DOM elements
const connectWalletBtn = document.getElementById('connect-wallet-btn');
const walletInfo = document.getElementById('wallet-info');
const walletAddress = document.getElementById('wallet-address');
const generateBtn = document.getElementById('generate-btn');
const hexagramDisplay = document.getElementById('hexagram-display');
const hexagramNumber = document.getElementById('hexagram-number');
const hexagramName = document.getElementById('hexagram-name');
const hexagramMeaning = document.getElementById('hexagram-meaning');
const loading = document.getElementById('loading');
const transactionResult = document.getElementById('transaction-result');
const transactionLink = document.getElementById('transaction-link');

// Solana connection
const connection = new Connection(clusterApiUrl('devnet'), 'confirmed');

// Program ID (replace with your actual program ID)
const programId = new PublicKey('Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS');

// Mock wallet for demo purposes
let wallet = null;
let program = null;
let ichingAccount = null;

// Connect wallet
connectWalletBtn.addEventListener('click', async () => {
  try {
    // In a real app, you would use a wallet adapter like Phantom
    // For this demo, we'll simulate a wallet connection
    
    // Simulate wallet connection
    wallet = web3.Keypair.generate();
    
    // Display wallet info
    walletInfo.classList.remove('hidden');
    walletAddress.textContent = wallet.publicKey.toString().slice(0, 8) + '...' + wallet.publicKey.toString().slice(-8);
    connectWalletBtn.textContent = 'Wallet Connected';
    connectWalletBtn.disabled = true;
    
    // Enable generate button
    generateBtn.disabled = false;
    
    // Initialize the program
    const provider = new AnchorProvider(
      connection,
      { publicKey: wallet.publicKey, signTransaction: async (tx) => tx, signAllTransactions: async (txs) => txs },
      { commitment: 'confirmed' }
    );
    
    // In a real app, you would load the IDL from the chain or a file
    // For this demo, we'll simulate program interaction
    
    console.log('Wallet connected:', wallet.publicKey.toString());
    
    // For demo purposes, display a random hexagram
    displayRandomHexagram();
    
  } catch (error) {
    console.error('Error connecting wallet:', error);
    alert('Failed to connect wallet. See console for details.');
  }
});

// Generate hexagram
generateBtn.addEventListener('click', async () => {
  try {
    // Show loading
    loading.classList.remove('hidden');
    generateBtn.disabled = true;
    
    // In a real app, you would call the on-chain program
    // For this demo, we'll simulate the transaction
    
    // Simulate transaction delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Display a random hexagram
    displayRandomHexagram();
    
    // Simulate transaction hash
    const txHash = 'SimulatedTxHash' + Math.random().toString(36).substring(2, 15);
    
    // Show transaction result
    transactionLink.textContent = txHash;
    transactionLink.href = `https://explorer.solana.com/tx/${txHash}?cluster=devnet`;
    transactionResult.classList.remove('hidden');
    
    // Hide loading
    loading.classList.add('hidden');
    generateBtn.disabled = false;
    
  } catch (error) {
    console.error('Error generating hexagram:', error);
    alert('Failed to generate hexagram. See console for details.');
    
    // Hide loading
    loading.classList.add('hidden');
    generateBtn.disabled = false;
  }
});

// Display a random hexagram
function displayRandomHexagram() {
  // Clear previous hexagram
  hexagramDisplay.innerHTML = '';
  
  // Generate 6 random lines (0 for yin, 1 for yang)
  let binaryString = '';
  
  for (let i = 0; i < 6; i++) {
    const isYang = Math.random() < 0.5;
    binaryString += isYang ? '1' : '0';
    
    // Create line element
    const lineDiv = document.createElement('div');
    lineDiv.className = 'line';
    
    if (isYang) {
      // Yang line (solid)
      const yangLine = document.createElement('div');
      yangLine.className = 'yang';
      lineDiv.appendChild(yangLine);
    } else {
      // Yin line (broken)
      const yinLine1 = document.createElement('div');
      yinLine1.className = 'yin';
      const yinLine2 = document.createElement('div');
      yinLine2.className = 'yin';
      lineDiv.appendChild(yinLine1);
      lineDiv.appendChild(yinLine2);
    }
    
    hexagramDisplay.appendChild(lineDiv);
  }
  
  // For demo purposes, select a random hexagram
  const randomHexagram = hexagrams[Math.floor(Math.random() * 2)]; // Using only the first 2 for demo
  
  hexagramNumber.textContent = `Hexagram ${randomHexagram.number}`;
  hexagramName.textContent = randomHexagram.name;
  hexagramMeaning.textContent = randomHexagram.meaning;
}
