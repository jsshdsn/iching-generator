// The 64 I Ching hexagrams with their numbers, names, and meanings
const hexagrams = [
  { 
    number: 1, 
    name: "Force (Qián)", 
    binary: "111111",
    meaning: "The Creative, Heaven. The creative power is the beginning of all things. It is strong, dynamic, and persevering. This hexagram suggests creative power, strength, and the ability to bring ideas into reality. It encourages taking initiative and leadership."
  },
  { 
    number: 2, 
    name: "Field (Kūn)", 
    binary: "000000",
    meaning: "The Receptive, Earth. The receptive power represents the perfect complement to the creative power. It is yielding, devoted, and receptive. This hexagram suggests receptivity, patience, and nurturing. It encourages acceptance and following rather than leading."
  },
  { 
    number: 3, 
    name: "Sprouting (Zhūn)", 
    binary: "010001",
    meaning: "Difficulty at the Beginning. Initial obstacles and chaos mark the beginning of growth. This hexagram suggests a time of initial challenges that require patience and perseverance. It encourages careful planning and seeking help when needed."
  },
  { 
    number: 4, 
    name: "Enveloping (Méng)", 
    binary: "100010",
    meaning: "Youthful Folly. Inexperience leads to a need for guidance and education. This hexagram suggests a time of learning and development. It encourages seeking wisdom from teachers and being open to instruction."
  },
  { 
    number: 5, 
    name: "Attending (Xū)", 
    binary: "111010",
    meaning: "Waiting, Nourishment. Patience and timing are essential. This hexagram suggests a time of waiting for the right moment. It encourages preparation, patience, and maintaining a positive attitude while waiting."
  },
  { 
    number: 6, 
    name: "Arguing (Sòng)", 
    binary: "010111",
    meaning: "Conflict. Disagreement and tension require careful handling. This hexagram suggests a time of conflict or dispute. It encourages compromise, honesty, and avoiding unnecessary confrontation."
  },
  { 
    number: 7, 
    name: "Leading (Shī)", 
    binary: "010000",
    meaning: "The Army. Discipline and organization are needed to achieve goals. This hexagram suggests a need for structure, discipline, and leadership. It encourages working together with others in an organized way."
  },
  { 
    number: 8, 
    name: "Grouping (Bǐ)", 
    binary: "000010",
    meaning: "Holding Together. Unity and solidarity bring success. This hexagram suggests the importance of cooperation and community. It encourages building relationships and finding common ground with others."
  },
  { 
    number: 9, 
    name: "Small Accumulating (Xiǎo Chù)", 
    binary: "111011",
    meaning: "Small Taming. Gentle restraint leads to progress. This hexagram suggests making small, careful adjustments rather than dramatic changes. It encourages patience and attention to detail."
  },
  { 
    number: 10, 
    name: "Treading (Lǚ)", 
    binary: "110111",
    meaning: "Treading Carefully. Conduct yourself with care and respect. This hexagram suggests proceeding with caution and awareness. It encourages respectful behavior and careful attention to one's conduct."
  },
  { 
    number: 11, 
    name: "Pervading (Tài)", 
    binary: "111000",
    meaning: "Peace. Harmony between heaven and earth brings prosperity. This hexagram suggests a time of peace, harmony, and flourishing. It encourages openness and enjoying the current state of balance."
  },
  { 
    number: 12, 
    name: "Obstruction (Pǐ)", 
    binary: "000111",
    meaning: "Standstill. When heaven and earth do not communicate, things come to a halt. This hexagram suggests a time of stagnation or blockage. It encourages patience and inner development during external difficulties."
  },
  { 
    number: 13, 
    name: "Concording People (Tóng Rén)", 
    binary: "101111",
    meaning: "Fellowship with Others. Harmony in community brings success. This hexagram suggests the importance of cooperation and community. It encourages working together with others toward common goals."
  },
  { 
    number: 14, 
    name: "Great Possessing (Dà Yǒu)", 
    binary: "111101",
    meaning: "Possession in Great Measure. Great abundance requires great responsibility. This hexagram suggests a time of abundance and prosperity. It encourages generosity and responsible management of resources."
  },
  { 
    number: 15, 
    name: "Humbling (Qiān)", 
    binary: "001000",
    meaning: "Modesty. Humility brings success. This hexagram suggests the value of modesty and humility. It encourages being unpretentious and receptive to learning from others."
  },
  { 
    number: 16, 
    name: "Providing-For (Yù)", 
    binary: "000100",
    meaning: "Enthusiasm. Cooperation and preparation bring success. This hexagram suggests enthusiasm and readiness. It encourages preparation and gathering support for new ventures."
  },
  { 
    number: 17, 
    name: "Following (Suí)", 
    binary: "100110",
    meaning: "Following. Adapting to change brings success. This hexagram suggests the importance of adaptability and following appropriate leadership. It encourages flexibility and appropriate responsiveness."
  },
  { 
    number: 18, 
    name: "Corrupting (Gǔ)", 
    binary: "011001",
    meaning: "Work on the Decayed. Addressing corruption or decay is necessary. This hexagram suggests a need to correct what has been spoiled or neglected. It encourages decisive action to remedy problems."
  },
  { 
    number: 19, 
    name: "Nearing (Lín)", 
    binary: "110000",
    meaning: "Approach. A time of advancement and influence. This hexagram suggests a time of approach and advancement. It encourages taking initiative and exerting positive influence."
  },
  { 
    number: 20, 
    name: "Viewing (Guān)", 
    binary: "000011",
    meaning: "Contemplation. Careful observation leads to understanding. This hexagram suggests a time for contemplation and observation. It encourages thoughtful reflection before taking action."
  },
  { 
    number: 21, 
    name: "Gnawing Bite (Shì Kè)", 
    binary: "100101",
    meaning: "Biting Through. Obstacles must be overcome with decisive action. This hexagram suggests a need to break through obstacles with determination. It encourages decisive action and persistence."
  },
  { 
    number: 22, 
    name: "Adorning (Bì)", 
    binary: "101001",
    meaning: "Grace. Beauty and form enhance substance. This hexagram suggests the importance of aesthetic qualities and presentation. It encourages attention to form as well as content."
  },
  { 
    number: 23, 
    name: "Stripping (Bō)", 
    binary: "000001",
    meaning: "Splitting Apart. Deterioration requires careful response. This hexagram suggests a time of decline or deterioration. It encourages acceptance and careful management of difficult changes."
  },
  { 
    number: 24, 
    name: "Returning (Fù)", 
    binary: "100000",
    meaning: "Return. After decline comes renewal. This hexagram suggests a time of return and renewal. It encourages recognizing and nurturing new beginnings after difficulties."
  },
  { 
    number: 25, 
    name: "Without Embroiling (Wú Wàng)", 
    binary: "100111",
    meaning: "Innocence. Natural simplicity brings good fortune. This hexagram suggests the value of innocence and naturalness. It encourages spontaneity and acting without ulterior motives."
  },
  { 
    number: 26, 
    name: "Great Accumulating (Dà Chù)", 
    binary: "111001",
    meaning: "The Taming Power of the Great. Great energy must be properly contained. This hexagram suggests the importance of disciplining and channeling powerful forces. It encourages restraint and proper management of energy."
  },
  { 
    number: 27, 
    name: "Swallowing (Yí)", 
    binary: "100001",
    meaning: "Nourishment. Proper nourishment sustains development. This hexagram suggests the importance of proper nourishment and care. It encourages attention to what sustains and supports growth."
  },
  { 
    number: 28, 
    name: "Great Exceeding (Dà Guò)", 
    binary: "011110",
    meaning: "Preponderance of the Great. Extraordinary times require extraordinary measures. This hexagram suggests a time when normal limits are exceeded. It encourages bold action while maintaining balance."
  },
  { 
    number: 29, 
    name: "Gorge (Kǎn)", 
    binary: "010010",
    meaning: "The Abysmal Water. Danger requires caution and persistence. This hexagram suggests a time of danger and challenge. It encourages caution, perseverance, and maintaining integrity in difficult times."
  },
  { 
    number: 30, 
    name: "Radiance (Lí)", 
    binary: "101101",
    meaning: "The Clinging, Fire. Clarity and dependence bring awareness. This hexagram suggests the importance of clarity and illumination. It encourages awareness, understanding, and appropriate attachment."
  },
  { 
    number: 31, 
    name: "Conjoining (Xián)", 
    binary: "001110",
    meaning: "Influence. Sensitivity and attraction lead to connection. This hexagram suggests the power of influence and attraction. It encourages sensitivity to others and gentle persuasion."
  },
  { 
    number: 32, 
    name: "Persevering (Héng)", 
    binary: "011100",
    meaning: "Duration. Constancy brings success. This hexagram suggests the importance of endurance and consistency. It encourages steady, continuous effort rather than sporadic action."
  },
  { 
    number: 33, 
    name: "Retiring (Dùn)", 
    binary: "001111",
    meaning: "Retreat. Strategic withdrawal conserves strength. This hexagram suggests the wisdom of strategic retreat. It encourages knowing when to withdraw and conserve energy for future action."
  },
  { 
    number: 34, 
    name: "Great Invigorating (Dà Zhuàng)", 
    binary: "111100",
    meaning: "The Power of the Great. Great power requires great restraint. This hexagram suggests a time of great strength and power. It encourages using power wisely and with restraint."
  },
  { 
    number: 35, 
    name: "Prospering (Jìn)", 
    binary: "000101",
    meaning: "Progress. Gradual advancement brings success. This hexagram suggests a time of progress and advancement. It encourages patience and gradual development rather than hasty action."
  },
  { 
    number: 36, 
    name: "Brightness Hiding (Míng Yí)", 
    binary: "101000",
    meaning: "Darkening of the Light. In darkness, maintain inner light. This hexagram suggests a time when brightness is obscured. It encourages maintaining inner integrity during difficult external circumstances."
  },
  { 
    number: 37, 
    name: "Dwelling People (Jiā Rén)", 
    binary: "101011",
    meaning: "The Family. Proper relationships create harmony. This hexagram suggests the importance of family and proper relationships. It encourages clear roles and loving connections."
  },
  { 
    number: 38, 
    name: "Polarising (Kuí)", 
    binary: "110101",
    meaning: "Opposition. Differences can be complementary. This hexagram suggests a time of opposition or difference. It encourages finding complementary aspects in seemingly opposed situations."
  },
  { 
    number: 39, 
    name: "Limping (Jiǎn)", 
    binary: "001010",
    meaning: "Obstruction. Difficulties require reassessment. This hexagram suggests a time of obstruction and difficulty. It encourages retreating to reassess and seeking help when needed."
  },
  { 
    number: 40, 
    name: "Taking-Apart (Xiè)", 
    binary: "010100",
    meaning: "Deliverance. Release from tension brings relief. This hexagram suggests a time of liberation from difficulty. It encourages resolving tensions and moving toward greater ease."
  },
  { 
    number: 41, 
    name: "Diminishing (Sǔn)", 
    binary: "110001",
    meaning: "Decrease. Reduction can lead to increase elsewhere. This hexagram suggests a time of decrease or reduction. It encourages accepting necessary losses and finding value in simplification."
  },
  { 
    number: 42, 
    name: "Augmenting (Yì)", 
    binary: "100011",
    meaning: "Increase. Growth and abundance through generosity. This hexagram suggests a time of increase and expansion. It encourages generosity and sharing good fortune with others."
  },
  { 
    number: 43, 
    name: "Parting (Guài)", 
    binary: "111110",
    meaning: "Breakthrough. Decisive action brings resolution. This hexagram suggests a time of breakthrough and resolution. It encourages decisive action to overcome resistance."
  },
  { 
    number: 44, 
    name: "Coupling (Gòu)", 
    binary: "011111",
    meaning: "Coming to Meet. Unexpected encounters require caution. This hexagram suggests a time of unexpected encounters or influences. It encourages caution and careful assessment of new situations."
  },
  { 
    number: 45, 
    name: "Clustering (Cuì)", 
    binary: "000110",
    meaning: "Gathering Together. Unity brings abundance. This hexagram suggests the importance of gathering and unity. It encourages bringing people together for common purposes."
  },
  { 
    number: 46, 
    name: "Ascending (Shēng)", 
    binary: "011000",
    meaning: "Pushing Upward. Gradual progress through effort. This hexagram suggests a time of upward movement and growth. It encourages steady effort and gradual advancement."
  },
  { 
    number: 47, 
    name: "Confining (Kùn)", 
    binary: "010110",
    meaning: "Oppression, Exhaustion. Difficult times require inner strength. This hexagram suggests a time of exhaustion or limitation. It encourages inner perseverance and finding meaning in difficult circumstances."
  },
  { 
    number: 48, 
    name: "Welling (Jǐng)", 
    binary: "011010",
    meaning: "The Well. The source of nourishment needs maintenance. This hexagram suggests the importance of reliable sources of nourishment. It encourages maintaining what sustains community."
  },
  { 
    number: 49, 
    name: "Skinning (Gé)", 
    binary: "101110",
    meaning: "Revolution. Necessary change requires proper timing. This hexagram suggests a time of significant change or revolution. It encourages careful timing and clear communication during transitions."
  },
  { 
    number: 50, 
    name: "Holding (Dǐng)", 
    binary: "011101",
    meaning: "The Cauldron. Transformation creates new value. This hexagram suggests the importance of transformation and creating new forms. It encourages receptivity to change and new influences."
  },
  { 
    number: 51, 
    name: "Shake (Zhèn)", 
    binary: "100100",
    meaning: "The Arousing, Thunder. Sudden change brings clarity. This hexagram suggests a time of sudden movement or awakening. It encourages remaining centered during shocking or surprising events."
  },
  { 
    number: 52, 
    name: "Bound (Gèn)", 
    binary: "001001",
    meaning: "Keeping Still, Mountain. Stillness brings clarity. This hexagram suggests the importance of stillness and restraint. It encourages meditation and careful consideration before action."
  },
  { 
    number: 53, 
    name: "Infiltrating (Jiàn)", 
    binary: "001011",
    meaning: "Development. Gradual progress brings success. This hexagram suggests the value of gradual development. It encourages patience and steady progress toward goals."
  },
  { 
    number: 54, 
    name: "Converting The Maiden (Guī Mèi)", 
    binary: "110100",
    meaning: "The Marrying Maiden. Relationships must respect proper order. This hexagram suggests the importance of proper roles in relationships. It encourages patience and acceptance of one's position."
  },
  { 
    number: 55, 
    name: "Abounding (Fēng)", 
    binary: "101100",
    meaning: "Abundance. Peak prosperity requires awareness. This hexagram suggests a time of abundance and fullness. It encourages awareness that peak conditions are temporary."
  },
  { 
    number: 56, 
    name: "Sojourning (Lǚ)", 
    binary: "001101",
    meaning: "The Wanderer. While traveling, maintain integrity. This hexagram suggests a time of being in unfamiliar territory. It encourages adaptability while maintaining core principles."
  },
  { 
    number: 57, 
    name: "Ground (Xùn)", 
    binary: "011011",
    meaning: "The Gentle, Wind. Gentle penetration brings influence. This hexagram suggests the power of gentle, persistent influence. It encourages subtle action rather than force."
  },
  { 
    number: 58, 
    name: "Open (Duì)", 
    binary: "110110",
    meaning: "The Joyous, Lake. Joy and openness bring connection. This hexagram suggests the importance of joy and open communication. It encourages expressing positive emotions and sharing with others."
  },
  { 
    number: 59, 
    name: "Dispersing (Huàn)", 
    binary: "010011",
    meaning: "Dispersion. Dissolving barriers brings unity. This hexagram suggests a time of dispersing blockages or divisions. It encourages releasing tension and promoting harmony."
  },
  { 
    number: 60, 
    name: "Articulating (Jié)", 
    binary: "110010",
    meaning: "Limitation. Proper boundaries create freedom. This hexagram suggests the importance of appropriate limitations and boundaries. It encourages establishing clear limits that support rather than restrict."
  },
  { 
    number: 61, 
    name: "Center Confirming (Zhōng Fú)", 
    binary: "110011",
    meaning: "Inner Truth. Sincerity and confidence bring success. This hexagram suggests the importance of inner truth and sincerity. It encourages confidence in one's inner knowing."
  },
  { 
    number: 62, 
    name: "Small Exceeding (Xiǎo Guò)", 
    binary: "001100",
    meaning: "Preponderance of the Small. Small matters require attention. This hexagram suggests focusing on small details rather than grand gestures. It encourages humility and attention to minor matters."
  },
  { 
    number: 63, 
    name: "Already Fording (Jì Jì)", 
    binary: "101010",
    meaning: "After Completion. Maintain balance after success. This hexagram suggests a time when a cycle is complete. It encourages vigilance and maintaining balance even after achieving success."
  },
  { 
    number: 64, 
    name: "Not-Yet Fording (Wèi Jì)", 
    binary: "010101",
    meaning: "Before Completion. Final stages require care. This hexagram suggests a time when completion is near but not yet achieved. It encourages careful attention to final details before conclusion."
  }
];

export default hexagrams;
